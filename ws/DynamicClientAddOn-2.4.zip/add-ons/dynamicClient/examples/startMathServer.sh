#!/bin/bash

cd server
ant run

