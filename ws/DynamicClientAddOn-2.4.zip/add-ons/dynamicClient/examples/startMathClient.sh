#!/bin/bash

cd client
ant run

